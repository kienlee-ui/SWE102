/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pkg2810;

/**
 *
 * @author PC
 */
public class Main {
public static void main(String[] args) {
       
        String Str = new String("I want to to go to the the zo0");
         //System.out.println(Str.replaceAll("to to", " Replace "));
        System.out.println(Str.replaceAll("(.+?)\\1+", " Replace "));


         System.out.print("" );
         System.out.print("input\n" );
         String th = new String("toi co 1 1 2 giac mo mo he he");
         System.out.print("Output: " );
         System.out.println(th.replaceAll("(.+?)\\1+", " Replace "));
         
         System.out.print("input\n" );
         String tr = new String("em co 1 1 2 3 cay keo\n");
         System.out.print("Output: " );
         System.out.println(tr.replaceAll("(.+?)\\1+", " Replace "));


      
         
    }
}
    

